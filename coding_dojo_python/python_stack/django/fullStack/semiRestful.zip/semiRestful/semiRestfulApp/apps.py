from django.apps import AppConfig


class SemirestfulappConfig(AppConfig):
    name = 'semiRestfulApp'
