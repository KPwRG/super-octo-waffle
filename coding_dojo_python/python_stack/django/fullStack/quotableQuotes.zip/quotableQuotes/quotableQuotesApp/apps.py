from django.apps import AppConfig


class QuotablequotesappConfig(AppConfig):
    name = 'quotableQuotesApp'
