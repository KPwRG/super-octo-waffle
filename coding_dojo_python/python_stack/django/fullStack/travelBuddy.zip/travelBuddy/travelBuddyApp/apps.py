from django.apps import AppConfig


class TravelbuddyappConfig(AppConfig):
    name = 'travelBuddyApp'
